#!/bin/bash
#************************************************************
#      genrate trace files from iperf with trace information 
#************************************************************


process_iperf_trace iperf-trace-tcp-q1-c1-p-ixia-p-c2-q2-highspeed-no-loss-2streams-trace-114ms-August-10-23-13:58-times-1-streams-2-parallel-1-1-test-1.txt highspeed_114ms_trace_1.txt
process_iperf_trace iperf-trace-tcp-q1-c1-p-ixia-p-c2-q2-highspeed-no-loss-2streams-trace-130ms-August-10-23-13:58-times-1-streams-2-parallel-1-1-test-1.txt highspeed_130ms_trace_1.txt
process_iperf_trace iperf-trace-tcp-q1-c1-p-ixia-p-c2-q2-highspeed-no-loss-2streams-trace-13ms-August-10-23-13:58-times-1-streams-2-parallel-1-1-test-1.txt highspeed_13ms_trace_1.txt
process_iperf_trace iperf-trace-tcp-q1-c1-p-ixia-p-c2-q2-highspeed-no-loss-2streams-trace-170ms-August-10-23-13:58-times-1-streams-2-parallel-1-1-test-1.txt highspeed_170ms_trace_1.txt
process_iperf_trace iperf-trace-tcp-q1-c1-p-ixia-p-c2-q2-highspeed-no-loss-2streams-trace-1ms-August-10-23-13:58-times-1-streams-2-parallel-1-1-test-1.txt highspeed_1ms_trace_1.txt
process_iperf_trace iperf-trace-tcp-q1-c1-p-ixia-p-c2-q2-highspeed-no-loss-2streams-trace-202ms-August-10-23-13:58-times-1-streams-2-parallel-1-1-test-1.txt highspeed_202ms_trace_1.txt
process_iperf_trace iperf-trace-tcp-q1-c1-p-ixia-p-c2-q2-highspeed-no-loss-2streams-trace-225ms-August-10-23-13:58-times-1-streams-2-parallel-1-1-test-1.txt highspeed_225ms_trace_1.txt
process_iperf_trace iperf-trace-tcp-q1-c1-p-ixia-p-c2-q2-highspeed-no-loss-2streams-trace-248ms-August-10-23-13:58-times-1-streams-2-parallel-1-1-test-1.txt highspeed_248ms_trace_1.txt
process_iperf_trace iperf-trace-tcp-q1-c1-p-ixia-p-c2-q2-highspeed-no-loss-2streams-trace-24ms-August-10-23-13:58-times-1-streams-2-parallel-1-1-test-1.txt highspeed_24ms_trace_1.txt
process_iperf_trace iperf-trace-tcp-q1-c1-p-ixia-p-c2-q2-highspeed-no-loss-2streams-trace-287ms-August-10-23-13:58-times-1-streams-2-parallel-1-1-test-1.txt highspeed_287ms_trace_1.txt
process_iperf_trace iperf-trace-tcp-q1-c1-p-ixia-p-c2-q2-highspeed-no-loss-2streams-trace-319ms-August-10-23-13:58-times-1-streams-2-parallel-1-1-test-1.txt highspeed_319ms_trace_1.txt
process_iperf_trace iperf-trace-tcp-q1-c1-p-ixia-p-c2-q2-highspeed-no-loss-2streams-trace-32ms-August-10-23-13:58-times-1-streams-2-parallel-1-1-test-1.txt highspeed_32ms_trace_1.txt
process_iperf_trace iperf-trace-tcp-q1-c1-p-ixia-p-c2-q2-highspeed-no-loss-2streams-trace-376ms-August-10-23-13:58-times-1-streams-2-parallel-1-1-test-1.txt highspeed_376ms_trace_1.txt
process_iperf_trace iperf-trace-tcp-q1-c1-p-ixia-p-c2-q2-highspeed-no-loss-2streams-trace-47ms-August-10-23-13:58-times-1-streams-2-parallel-1-1-test-1.txt highspeed_47ms_trace_1.txt
process_iperf_trace iperf-trace-tcp-q1-c1-p-ixia-p-c2-q2-highspeed-no-loss-2streams-trace-60ms-August-10-23-13:58-times-1-streams-2-parallel-1-1-test-1.txt highspeed_60ms_trace_1.txt
process_iperf_trace iperf-trace-tcp-q1-c1-p-ixia-p-c2-q2-highspeed-no-loss-2streams-trace-81ms-August-10-23-13:58-times-1-streams-2-parallel-1-1-test-1.txt highspeed_81ms_trace_1.txt
process_iperf_trace iperf-trace-tcp-q1-c1-p-ixia-p-c2-q2-highspeed-no-loss-2streams-trace-91ms-August-10-23-13:58-times-1-streams-2-parallel-1-1-test-1.txt highspeed_91ms_trace_1.txt


# highspeed_114ms_trace_1.txt
# highspeed_130ms_trace_1.txt
# highspeed_13ms_trace_1.txt
# highspeed_1ms_trace_1.txt
# highspeed_202ms_trace_1.txt
# highspeed_225ms_trace_1.txt
# highspeed_248ms_trace_1.txt
# highspeed_24ms_trace_1.txt
# highspeed_287ms_trace_1.txt
# highspeed_319ms_trace_1.txt
# highspeed_32ms_trace_1.txt
# highspeed_376ms_trace_1.txt
# highspeed_47ms_trace_1.txt
# highspeed_60ms_trace_1.txt
# highspeed_81ms_trace_1.txt
# highspeed_91ms_trace_1.txt
