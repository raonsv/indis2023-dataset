#!/bin/bash
#************************************************************
#      genrate trace files from iperf with trace information 
#************************************************************


process_iperf_trace iperf-trace-tcp-q1-c1-p-ixia-p-c2-q2-htcp-no-loss-2streams-trace-114ms-August-10-23-09:49-times-1-streams-2-parallel-2-1-test-1.txt htcp_114ms_trace_21.txt
process_iperf_trace iperf-trace-tcp-q1-c1-p-ixia-p-c2-q2-htcp-no-loss-2streams-trace-130ms-August-10-23-09:49-times-1-streams-2-parallel-2-1-test-1.txt htcp_130ms_trace_21.txt
process_iperf_trace iperf-trace-tcp-q1-c1-p-ixia-p-c2-q2-htcp-no-loss-2streams-trace-13ms-August-10-23-09:49-times-1-streams-2-parallel-2-1-test-1.txt htcp_13ms_trace_21.txt
process_iperf_trace iperf-trace-tcp-q1-c1-p-ixia-p-c2-q2-htcp-no-loss-2streams-trace-170ms-August-10-23-09:49-times-1-streams-2-parallel-2-1-test-1.txt htcp_170ms_trace_21.txt
process_iperf_trace iperf-trace-tcp-q1-c1-p-ixia-p-c2-q2-htcp-no-loss-2streams-trace-1ms-August-10-23-09:49-times-1-streams-2-parallel-2-1-test-1.txt htcp_1ms_trace_21.txt
process_iperf_trace iperf-trace-tcp-q1-c1-p-ixia-p-c2-q2-htcp-no-loss-2streams-trace-202ms-August-10-23-09:49-times-1-streams-2-parallel-2-1-test-1.txt htcp_202ms_trace_21.txt
process_iperf_trace iperf-trace-tcp-q1-c1-p-ixia-p-c2-q2-htcp-no-loss-2streams-trace-225ms-August-10-23-09:49-times-1-streams-2-parallel-2-1-test-1.txt htcp_225ms_trace_21.txt
process_iperf_trace iperf-trace-tcp-q1-c1-p-ixia-p-c2-q2-htcp-no-loss-2streams-trace-248ms-August-10-23-09:49-times-1-streams-2-parallel-2-1-test-1.txt htcp_248ms_trace_21.txt
process_iperf_trace iperf-trace-tcp-q1-c1-p-ixia-p-c2-q2-htcp-no-loss-2streams-trace-24ms-August-10-23-09:49-times-1-streams-2-parallel-2-1-test-1.txt htcp_24ms_trace_21.txt
process_iperf_trace iperf-trace-tcp-q1-c1-p-ixia-p-c2-q2-htcp-no-loss-2streams-trace-287ms-August-10-23-09:49-times-1-streams-2-parallel-2-1-test-1.txt htcp_287ms_trace_21.txt
process_iperf_trace iperf-trace-tcp-q1-c1-p-ixia-p-c2-q2-htcp-no-loss-2streams-trace-319ms-August-10-23-09:49-times-1-streams-2-parallel-2-1-test-1.txt htcp_319ms_trace_21.txt
process_iperf_trace iperf-trace-tcp-q1-c1-p-ixia-p-c2-q2-htcp-no-loss-2streams-trace-32ms-August-10-23-09:49-times-1-streams-2-parallel-2-1-test-1.txt htcp_32ms_trace_21.txt
process_iperf_trace iperf-trace-tcp-q1-c1-p-ixia-p-c2-q2-htcp-no-loss-2streams-trace-376ms-August-10-23-09:49-times-1-streams-2-parallel-2-1-test-1.txt htcp_376ms_trace_21.txt
process_iperf_trace iperf-trace-tcp-q1-c1-p-ixia-p-c2-q2-htcp-no-loss-2streams-trace-47ms-August-10-23-09:49-times-1-streams-2-parallel-2-1-test-1.txt htcp_47ms_trace_21.txt
process_iperf_trace iperf-trace-tcp-q1-c1-p-ixia-p-c2-q2-htcp-no-loss-2streams-trace-60ms-August-10-23-09:49-times-1-streams-2-parallel-2-1-test-1.txt htcp_60ms_trace_21.txt
process_iperf_trace iperf-trace-tcp-q1-c1-p-ixia-p-c2-q2-htcp-no-loss-2streams-trace-81ms-August-10-23-09:49-times-1-streams-2-parallel-2-1-test-1.txt htcp_81ms_trace_21.txt
process_iperf_trace iperf-trace-tcp-q1-c1-p-ixia-p-c2-q2-htcp-no-loss-2streams-trace-91ms-August-10-23-09:49-times-1-streams-2-parallel-2-1-test-1.txt htcp_91ms_trace_21.txt


# htcp_114ms_trace_21.txt
# htcp_130ms_trace_21.txt
# htcp_13ms_trace_21.txt
# htcp_1ms_trace_21.txt
# htcp_202ms_trace_21.txt
# htcp_225ms_trace_21.txt
# htcp_248ms_trace_21.txt
# htcp_24ms_trace_21.txt
# htcp_287ms_trace_21.txt
# htcp_319ms_trace_21.txt
# htcp_32ms_trace_21.txt
# htcp_376ms_trace_21.txt
# htcp_47ms_trace_21.txt
# htcp_60ms_trace_21.txt
# htcp_81ms_trace_21.txt
# htcp_91ms_trace_21.txt
