:!/bin/bash
#************************************************************
#      genrate trace files from iperf with trace information 
#************************************************************


process_iperf_trace iperf-trace-tcp-q1-c1-p-ixia-p-c2-q2-scalable-no-loss-2streams-trace-114ms-August-11-23-11:43-times-1-streams-2-parallel-2-2-test-1.txt scalable_114ms_trace_22.txt
process_iperf_trace iperf-trace-tcp-q1-c1-p-ixia-p-c2-q2-scalable-no-loss-2streams-trace-130ms-August-11-23-11:43-times-1-streams-2-parallel-2-2-test-1.txt scalable_130ms_trace_22.txt
process_iperf_trace iperf-trace-tcp-q1-c1-p-ixia-p-c2-q2-scalable-no-loss-2streams-trace-13ms-August-11-23-11:43-times-1-streams-2-parallel-2-2-test-1.txt scalable_13ms_trace_22.txt
process_iperf_trace iperf-trace-tcp-q1-c1-p-ixia-p-c2-q2-scalable-no-loss-2streams-trace-170ms-August-11-23-11:43-times-1-streams-2-parallel-2-2-test-1.txt scalable_170ms_trace_22.txt
process_iperf_trace iperf-trace-tcp-q1-c1-p-ixia-p-c2-q2-scalable-no-loss-2streams-trace-1ms-August-11-23-11:43-times-1-streams-2-parallel-2-2-test-1.txt scalable_1ms_trace_22.txt
process_iperf_trace iperf-trace-tcp-q1-c1-p-ixia-p-c2-q2-scalable-no-loss-2streams-trace-202ms-August-11-23-11:43-times-1-streams-2-parallel-2-2-test-1.txt scalable_202ms_trace_22.txt
process_iperf_trace iperf-trace-tcp-q1-c1-p-ixia-p-c2-q2-scalable-no-loss-2streams-trace-225ms-August-11-23-11:43-times-1-streams-2-parallel-2-2-test-1.txt scalable_225ms_trace_22.txt
process_iperf_trace iperf-trace-tcp-q1-c1-p-ixia-p-c2-q2-scalable-no-loss-2streams-trace-248ms-August-11-23-11:43-times-1-streams-2-parallel-2-2-test-1.txt scalable_248ms_trace_22.txt
process_iperf_trace iperf-trace-tcp-q1-c1-p-ixia-p-c2-q2-scalable-no-loss-2streams-trace-24ms-August-11-23-11:43-times-1-streams-2-parallel-2-2-test-1.txt scalable_24ms_trace_22.txt
process_iperf_trace iperf-trace-tcp-q1-c1-p-ixia-p-c2-q2-scalable-no-loss-2streams-trace-287ms-August-11-23-11:43-times-1-streams-2-parallel-2-2-test-1.txt scalable_287ms_trace_22.txt
process_iperf_trace iperf-trace-tcp-q1-c1-p-ixia-p-c2-q2-scalable-no-loss-2streams-trace-319ms-August-11-23-11:43-times-1-streams-2-parallel-2-2-test-1.txt scalable_319ms_trace_22.txt
process_iperf_trace iperf-trace-tcp-q1-c1-p-ixia-p-c2-q2-scalable-no-loss-2streams-trace-32ms-August-11-23-11:43-times-1-streams-2-parallel-2-2-test-1.txt scalable_32ms_trace_22.txt
process_iperf_trace iperf-trace-tcp-q1-c1-p-ixia-p-c2-q2-scalable-no-loss-2streams-trace-376ms-August-11-23-11:43-times-1-streams-2-parallel-2-2-test-1.txt scalable_376ms_trace_22.txt
process_iperf_trace iperf-trace-tcp-q1-c1-p-ixia-p-c2-q2-scalable-no-loss-2streams-trace-47ms-August-11-23-11:43-times-1-streams-2-parallel-2-2-test-1.txt scalable_47ms_trace_22.txt
process_iperf_trace iperf-trace-tcp-q1-c1-p-ixia-p-c2-q2-scalable-no-loss-2streams-trace-60ms-August-11-23-11:43-times-1-streams-2-parallel-2-2-test-1.txt scalable_60ms_trace_22.txt
process_iperf_trace iperf-trace-tcp-q1-c1-p-ixia-p-c2-q2-scalable-no-loss-2streams-trace-81ms-August-11-23-11:43-times-1-streams-2-parallel-2-2-test-1.txt scalable_81ms_trace_22.txt
process_iperf_trace iperf-trace-tcp-q1-c1-p-ixia-p-c2-q2-scalable-no-loss-2streams-trace-91ms-August-11-23-11:43-times-1-streams-2-parallel-2-2-test-1.txt scalable_91ms_trace_22.txt


# scalable_114ms_trace_22.txt
# scalable_130ms_trace_22.txt
# scalable_13ms_trace_22.txt
# scalable_1ms_trace_22.txt
# scalable_202ms_trace_22.txt
# scalable_225ms_trace_22.txt
# scalable_248ms_trace_22.txt
# scalable_24ms_trace_22.txt
# scalable_287ms_trace_22.txt
# scalable_319ms_trace_22.txt
# scalable_32ms_trace_22.txt
# scalable_376ms_trace_22.txt
# scalable_47ms_trace_22.txt
# scalable_60ms_trace_22.txt
# scalable_81ms_trace_22.txt
# scalable_91ms_trace_22.txt
