#!/bin/bash
#************************************************************
#      genrate trace files from iperf with trace information 
#************************************************************


process_iperf_trace iperf-trace-tcp-q1-c1-p-ixia-p-c2-vegas-no-loss-2streams-trace-114ms-August-23-23-16:54-times-1-streams-2-parallel-1-1-test-1.txt vegas_114ms_trace_1.txt
process_iperf_trace iperf-trace-tcp-q1-c1-p-ixia-p-c2-vegas-no-loss-2streams-trace-130ms-August-23-23-16:54-times-1-streams-2-parallel-1-1-test-1.txt vegas_130ms_trace_1.txt
process_iperf_trace iperf-trace-tcp-q1-c1-p-ixia-p-c2-vegas-no-loss-2streams-trace-13ms-August-23-23-16:54-times-1-streams-2-parallel-1-1-test-1.txt vegas_13ms_trace_1.txt
process_iperf_trace iperf-trace-tcp-q1-c1-p-ixia-p-c2-vegas-no-loss-2streams-trace-170ms-August-23-23-16:54-times-1-streams-2-parallel-1-1-test-1.txt vegas_170ms_trace_1.txt
process_iperf_trace iperf-trace-tcp-q1-c1-p-ixia-p-c2-vegas-no-loss-2streams-trace-1ms-August-23-23-16:54-times-1-streams-2-parallel-1-1-test-1.txt vegas_1ms_trace_1.txt
process_iperf_trace iperf-trace-tcp-q1-c1-p-ixia-p-c2-vegas-no-loss-2streams-trace-202ms-August-23-23-16:54-times-1-streams-2-parallel-1-1-test-1.txt vegas_202ms_trace_1.txt
process_iperf_trace iperf-trace-tcp-q1-c1-p-ixia-p-c2-vegas-no-loss-2streams-trace-225ms-August-23-23-16:54-times-1-streams-2-parallel-1-1-test-1.txt vegas_225ms_trace_1.txt
process_iperf_trace iperf-trace-tcp-q1-c1-p-ixia-p-c2-vegas-no-loss-2streams-trace-248ms-August-23-23-16:54-times-1-streams-2-parallel-1-1-test-1.txt vegas_248ms_trace_1.txt
process_iperf_trace iperf-trace-tcp-q1-c1-p-ixia-p-c2-vegas-no-loss-2streams-trace-24ms-August-23-23-16:54-times-1-streams-2-parallel-1-1-test-1.txt vegas_24ms_trace_1.txt
process_iperf_trace iperf-trace-tcp-q1-c1-p-ixia-p-c2-vegas-no-loss-2streams-trace-287ms-August-23-23-16:54-times-1-streams-2-parallel-1-1-test-1.txt vegas_287ms_trace_1.txt
process_iperf_trace iperf-trace-tcp-q1-c1-p-ixia-p-c2-vegas-no-loss-2streams-trace-319ms-August-23-23-16:54-times-1-streams-2-parallel-1-1-test-1.txt vegas_319ms_trace_1.txt
process_iperf_trace iperf-trace-tcp-q1-c1-p-ixia-p-c2-vegas-no-loss-2streams-trace-32ms-August-23-23-16:54-times-1-streams-2-parallel-1-1-test-1.txt vegas_32ms_trace_1.txt
process_iperf_trace iperf-trace-tcp-q1-c1-p-ixia-p-c2-vegas-no-loss-2streams-trace-376ms-August-23-23-16:54-times-1-streams-2-parallel-1-1-test-1.txt vegas_376ms_trace_1.txt
process_iperf_trace iperf-trace-tcp-q1-c1-p-ixia-p-c2-vegas-no-loss-2streams-trace-47ms-August-23-23-16:54-times-1-streams-2-parallel-1-1-test-1.txt vegas_47ms_trace_1.txt
process_iperf_trace iperf-trace-tcp-q1-c1-p-ixia-p-c2-vegas-no-loss-2streams-trace-60ms-August-23-23-16:54-times-1-streams-2-parallel-1-1-test-1.txt vegas_60ms_trace_1.txt
process_iperf_trace iperf-trace-tcp-q1-c1-p-ixia-p-c2-vegas-no-loss-2streams-trace-81ms-August-23-23-16:54-times-1-streams-2-parallel-1-1-test-1.txt vegas_81ms_trace_1.txt
process_iperf_trace iperf-trace-tcp-q1-c1-p-ixia-p-c2-vegas-no-loss-2streams-trace-91ms-August-23-23-16:54-times-1-streams-2-parallel-1-1-test-1.txt vegas_91ms_trace_1.txt


# vegas_114ms_trace_1.txt
# vegas_130ms_trace_1.txt
# vegas_13ms_trace_1.txt
# vegas_1ms_trace_1.txt
# vegas_202ms_trace_1.txt
# vegas_225ms_trace_1.txt
# vegas_248ms_trace_1.txt
# vegas_24ms_trace_1.txt
# vegas_287ms_trace_1.txt
# vegas_319ms_trace_1.txt
# vegas_32ms_trace_1.txt
# vegas_376ms_trace_1.txt
# vegas_47ms_trace_1.txt
# vegas_60ms_trace_1.txt
# vegas_81ms_trace_1.txt
# vegas_91ms_trace_1.txt
